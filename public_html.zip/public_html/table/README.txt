A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/qNoyAb.

 Based on: 
Material Design by Google (http://www.google.com/design/)

Tested on Win8.1 with browsers: Chrome 37, Firefox 32, Opera 25, IE 11, Safari 5.1.7

You can use this table in Bootstrap (v3) projects. Material Design Responsive Table CSS-style will override basic bootstrap style.